import React, { useState } from 'react';
import { ScreenType, StudentProfile, ClassSession, CampusEvent, NotificationItem } from './types';
import { INITIAL_STUDENT, INITIAL_CLASSES, INITIAL_EVENTS, INITIAL_NOTIFICATIONS } from './data/mockData';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { WelcomeScreen } from './screens/WelcomeScreen';
import { LoginScreen } from './screens/LoginScreen';
import { DashboardScreen } from './screens/DashboardScreen';
import { CalendarScreen } from './screens/CalendarScreen';
import { EventsScreen } from './screens/EventsScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { NotificationsModal } from './components/NotificationsModal';
import { AttendanceModal } from './components/AttendanceModal';
import { ClassDetailsModal } from './components/ClassDetailsModal';
import { EventPassModal } from './components/EventPassModal';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('dashboard');
  const [student, setStudent] = useState<StudentProfile>(INITIAL_STUDENT);
  const [classes, setClasses] = useState<ClassSession[]>(INITIAL_CLASSES);
  const [events, setEvents] = useState<CampusEvent[]>(INITIAL_EVENTS);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);

  // Modals state
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isAttendanceOpen, setIsAttendanceOpen] = useState(false);
  const [selectedClass, setSelectedClass] = useState<ClassSession | null>(null);
  const [selectedEventPass, setSelectedEventPass] = useState<CampusEvent | null>(null);

  // Quick toast or screen switcher toggle
  const [isFrameMode, setIsFrameMode] = useState(false);

  // Unread notifications count
  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleMarkAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const handleClearNotifications = () => {
    setNotifications([]);
  };

  // Toggle event registration
  const handleToggleEventRegister = (eventId: string) => {
    setEvents((prev) =>
      prev.map((e) => {
        if (e.id === eventId) {
          const nextRegistered = !e.registered;
          if (nextRegistered) {
            // Add notification
            setNotifications((n) => [
              {
                id: `notif-reg-${Date.now()}`,
                title: `${e.title} Pass Confirmed!`,
                message: `You are registered for ${e.title} at ${e.location}. Digital pass generated.`,
                time: 'Just now',
                read: false,
                type: 'event',
              },
              ...n,
            ]);
          }
          return { ...e, registered: nextRegistered };
        }
        return e;
      })
    );
  };

  // Attendance check-in from class modal
  const handleCheckInClass = (classId: string) => {
    setStudent((prev) => {
      const nextAttended = prev.attendedClasses + 1;
      const nextTotal = prev.totalClasses;
      const nextPct = Math.round((nextAttended / nextTotal) * 100);
      return {
        ...prev,
        attendedClasses: nextAttended,
        attendancePercent: nextPct,
      };
    });
  };

  // Switch to login
  const handleLogout = () => {
    setCurrentScreen('login');
  };

  // Screen header title & subtitle
  const getHeaderProps = () => {
    switch (currentScreen) {
      case 'calendar':
        return {
          title: 'Campus Connect',
          subtitle: 'Academic Calendar',
          showBack: true,
          onBack: () => setCurrentScreen('dashboard'),
        };
      case 'events':
        return {
          title: 'Campus Connect',
          subtitle: 'Events & Highlights',
          showBack: true,
          onBack: () => setCurrentScreen('dashboard'),
        };
      case 'profile':
        return {
          title: 'Campus Connect',
          subtitle: 'Student Identity',
          showBack: true,
          onBack: () => setCurrentScreen('dashboard'),
        };
      default:
        return {
          title: 'Campus Connect',
          subtitle: 'Student Dashboard',
          showBack: false,
        };
    }
  };

  return (
    <div className="min-h-screen bg-[#f3eeff] flex flex-col items-center justify-start text-[#1b192f] antialiased">
      {/* Top Prototype Navigation Bar */}
      <div className="w-full bg-[#1b192f] text-white py-2 px-3 shadow-md z-50 flex items-center justify-between text-xs overflow-x-auto gap-2">
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <span className="w-2 h-2 rounded-full bg-[#40d399] animate-pulse" />
          <span className="font-semibold text-[11px] text-[#e8ddff] tracking-wide uppercase">
            Screens:
          </span>
        </div>

        {/* Quick jump to the exact requested screens */}
        <div className="flex items-center gap-1 overflow-x-auto">
          <button
            type="button"
            onClick={() => setCurrentScreen('welcome')}
            className={`px-2.5 py-1 rounded-full font-medium transition-all whitespace-nowrap cursor-pointer text-[11px] ${
              currentScreen === 'welcome'
                ? 'bg-[#5521c7] text-white font-bold ring-1 ring-white/30'
                : 'bg-white/10 text-white/80 hover:bg-white/20'
            }`}
          >
            1. Welcome
          </button>

          <button
            type="button"
            onClick={() => setCurrentScreen('login')}
            className={`px-2.5 py-1 rounded-full font-medium transition-all whitespace-nowrap cursor-pointer text-[11px] ${
              currentScreen === 'login'
                ? 'bg-[#5521c7] text-white font-bold ring-1 ring-white/30'
                : 'bg-white/10 text-white/80 hover:bg-white/20'
            }`}
          >
            2. Login
          </button>

          <button
            type="button"
            onClick={() => setCurrentScreen('dashboard')}
            className={`px-2.5 py-1 rounded-full font-medium transition-all whitespace-nowrap cursor-pointer text-[11px] ${
              currentScreen === 'dashboard'
                ? 'bg-[#5521c7] text-white font-bold ring-1 ring-white/30'
                : 'bg-white/10 text-white/80 hover:bg-white/20'
            }`}
          >
            3. Dashboard
          </button>

          <button
            type="button"
            onClick={() => setCurrentScreen('calendar')}
            className={`px-2.5 py-1 rounded-full font-medium transition-all whitespace-nowrap cursor-pointer text-[11px] ${
              currentScreen === 'calendar'
                ? 'bg-[#5521c7] text-white font-bold ring-1 ring-white/30'
                : 'bg-white/10 text-white/80 hover:bg-white/20'
            }`}
          >
            Calendar
          </button>

          <button
            type="button"
            onClick={() => setCurrentScreen('events')}
            className={`px-2.5 py-1 rounded-full font-medium transition-all whitespace-nowrap cursor-pointer text-[11px] ${
              currentScreen === 'events'
                ? 'bg-[#5521c7] text-white font-bold ring-1 ring-white/30'
                : 'bg-white/10 text-white/80 hover:bg-white/20'
            }`}
          >
            Events
          </button>

          <button
            type="button"
            onClick={() => setCurrentScreen('profile')}
            className={`px-2.5 py-1 rounded-full font-medium transition-all whitespace-nowrap cursor-pointer text-[11px] ${
              currentScreen === 'profile'
                ? 'bg-[#5521c7] text-white font-bold ring-1 ring-white/30'
                : 'bg-white/10 text-white/80 hover:bg-white/20'
            }`}
          >
            Profile
          </button>
        </div>

        {/* View mode toggle */}
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <button
            type="button"
            onClick={() => setIsFrameMode(!isFrameMode)}
            className="hidden sm:inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-white/15 hover:bg-white/25 text-[11px] font-medium text-white transition-all cursor-pointer"
          >
            <span className="material-symbols-outlined text-[14px]">
              {isFrameMode ? 'fullscreen' : 'smartphone'}
            </span>
            {isFrameMode ? 'Full View' : 'Phone Shell'}
          </button>
        </div>
      </div>

      {/* Main Container Wrapper */}
      <div
        className={`w-full transition-all duration-300 flex justify-center ${
          isFrameMode ? 'py-4 sm:py-8' : ''
        }`}
      >
        <div
          className={`w-full bg-[#fcf8ff] relative min-h-screen flex flex-col ${
            isFrameMode
              ? 'max-w-[420px] rounded-[44px] shadow-2xl border-[10px] border-[#1b192f] overflow-hidden ring-1 ring-black/10'
              : 'max-w-md shadow-lg border-x border-[#e4dffe]/60'
          }`}
        >
          {/* Render Standalone Screens vs App Shell */}
          {currentScreen === 'welcome' && (
            <WelcomeScreen onNavigate={(scr) => setCurrentScreen(scr)} />
          )}

          {currentScreen === 'login' && (
            <LoginScreen
              onNavigate={(scr) => setCurrentScreen(scr)}
              onLoginSuccess={() => setCurrentScreen('dashboard')}
            />
          )}

          {currentScreen !== 'welcome' && currentScreen !== 'login' && (
            <div className="flex flex-col min-h-screen relative">
              {/* Sticky Top Header */}
              <Header
                {...getHeaderProps()}
                unreadCount={unreadCount}
                onOpenNotifications={() => setIsNotificationsOpen(true)}
                onOpenProfile={() => setCurrentScreen('profile')}
                currentScreen={currentScreen}
              />

              {/* Main Content Area */}
              <main className="flex-1 pt-20 pb-24">
                {currentScreen === 'dashboard' && (
                  <DashboardScreen
                    student={student}
                    classes={classes}
                    events={events}
                    onOpenNotifications={() => setIsNotificationsOpen(true)}
                    onOpenProfile={() => setCurrentScreen('profile')}
                    onSelectClass={(cls) => setSelectedClass(cls)}
                    onOpenAttendance={() => setIsAttendanceOpen(true)}
                    onViewAllClasses={() => setCurrentScreen('calendar')}
                    onToggleEventRegister={handleToggleEventRegister}
                    onViewEventPass={(ev) => setSelectedEventPass(ev)}
                  />
                )}

                {currentScreen === 'calendar' && (
                  <CalendarScreen
                    classes={classes}
                    events={events}
                    onSelectClass={(cls) => setSelectedClass(cls)}
                  />
                )}

                {currentScreen === 'events' && (
                  <EventsScreen
                    events={events}
                    onToggleEventRegister={handleToggleEventRegister}
                    onViewEventPass={(ev) => setSelectedEventPass(ev)}
                  />
                )}

                {currentScreen === 'profile' && (
                  <ProfileScreen
                    student={student}
                    onLogout={handleLogout}
                    onNavigate={(scr) => setCurrentScreen(scr)}
                  />
                )}
              </main>

              {/* Fixed Bottom Navigation */}
              <BottomNav
                currentScreen={currentScreen}
                onNavigate={(scr) => setCurrentScreen(scr)}
              />
            </div>
          )}
        </div>
      </div>

      {/* Global Modals & Drawers */}
      <NotificationsModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={notifications}
        onMarkAllAsRead={handleMarkAllNotificationsRead}
        onClear={handleClearNotifications}
      />

      <AttendanceModal
        isOpen={isAttendanceOpen}
        onClose={() => setIsAttendanceOpen(false)}
        student={student}
      />

      <ClassDetailsModal
        classSession={selectedClass}
        onClose={() => setSelectedClass(null)}
        onCheckIn={handleCheckInClass}
      />

      <EventPassModal
        event={selectedEventPass}
        student={student}
        onClose={() => setSelectedEventPass(null)}
      />
    </div>
  );
}
