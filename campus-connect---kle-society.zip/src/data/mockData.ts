import { StudentProfile, ClassSession, CampusEvent, NotificationItem } from '../types';

export const ASSETS = {
  logo: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD1AdTQAKw5Xs1xVkdLYDwgz2r_Gn5iCHyL2xHwmqY5acUpcFyiKnPDrDMEy6Q1DOBvb8su5ADGuvV7ZcgF4Fa8SvuscAZJNEP8OA8ODOO8v5Q1mNwdqCxRVdE2VyvUHvDxdQP7pWFwNHA1SfxN6I6G4DBkdAySJNpFNmieMegFzim0Iuqu2iqDZIuODv5kToST4xyFOyY5D9-1yVTqInGCt1gKXLXHvrFwDH0pS53TJh5E9w5btTWS',
  avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBys460HryEzaHkTIXOoGgdu9Sx9EvF-1GqcTnYr2b5AoXJadjDr3mjmGrW82z-bk0wv2YFfFI3Myf4FIHhZHEzuycZE85UrnJi9J5pWbzwbcDw9JUGyiisRjaNR8ve5FC43EJeSHgBU8vCtUl0d3UBUW-XJZI_GqWP7iw4tYQQmEeBl2yz9Xq6uHxSBASXK76yZxntcY_59AyBABwLV73Norfrw8V3PYottXFFH1Z5SSm5hjXIK1sM',
  campusView: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD_TtunA4ATUEyKNCVnJu8bXZLqPd1Ye3R0Rq0kWqQE0DRHpAt6qTB7k53kP1tDuAfQ_a8LP19NbekEnL-AtLZ5DkioJU-SCOyX6cEgpncB1ZC7jXgLJJVORNgU_0ycI5nhLCKYmS2DVCBXy_ufLzs_qA4HAodw6_zTTNP_sTbIBRbWKLpe431h7HXbQ4m5GOH42p_F5RwXQS4_lOcRMBOBJEQjsZOJdprkWkr8aAQK0m8uB818_322'
};

export const INITIAL_STUDENT: StudentProfile = {
  name: 'Sudarshan',
  email: 'student@klesociety.edu.in',
  studentId: 'KLE-2023-CS042',
  usn: '2KL23CS108',
  branch: 'Computer Science & Engineering',
  semester: '5th Semester (Autumn 2026)',
  college: 'KLE Society Institute of Technology',
  campus: 'Belagavi, Karnataka',
  avatarUrl: ASSETS.avatar,
  cgpa: 8.86,
  totalCredits: 160,
  completedCredits: 104,
  attendancePercent: 86,
  attendedClasses: 24,
  totalClasses: 28,
  mfaEnabled: true,
};

export const INITIAL_CLASSES: ClassSession[] = [
  {
    id: 'class-ds',
    title: 'Data Structure',
    time: '09:30 AM',
    duration: '1 hr 30 mins',
    room: 'Room B-204',
    instructor: 'Dr. Radhika Desai',
    colorBg: 'bg-[#e8ddff]',
    colorText: 'text-[#5521c7]',
    icon: 'account_tree',
    attended: 10,
    total: 11,
    topicToday: 'AVL Trees & Self-Balancing Binary Search Trees',
    syllabusUnit: 'Unit 3: Advanced Trees & Graphs',
    resources: [
      { name: 'Lecture 18 - AVL Tree Balance Factor.pdf', type: 'PDF' },
      { name: 'C++ AVL Implementation Code.zip', type: 'ZIP' }
    ]
  },
  {
    id: 'class-cc',
    title: 'Cloud Computing',
    time: '11:15 AM',
    duration: '1 hr',
    room: 'Room B-204',
    instructor: 'Prof. Amit Kulkarni',
    colorBg: 'bg-[#e7dbf6]',
    colorText: 'text-[#635b71]',
    icon: 'cloud_sync',
    attended: 8,
    total: 9,
    topicToday: 'Microservices Architecture & Containerization',
    syllabusUnit: 'Unit 4: Serverless & Kubernetes Orchestration',
    resources: [
      { name: 'Cloud Native Microservices Slides.pdf', type: 'PDF' },
      { name: 'Docker Compose Demo YAML', type: 'CODE' }
    ]
  },
  {
    id: 'class-py',
    title: 'Python Lab',
    time: '02:00 PM',
    duration: '2 hrs',
    room: 'Room B-204',
    instructor: 'Prof. Sneha Patil',
    colorBg: 'bg-[#e4dffe]',
    colorText: 'text-[#3d00a1]',
    icon: 'terminal',
    attended: 6,
    total: 8,
    topicToday: 'NumPy Matrix Operations & Data Analysis with Pandas',
    syllabusUnit: 'Lab Session 6: Scientific Computing & Visualization',
    resources: [
      { name: 'Lab Manual Exercise 6.ipynb', type: 'NOTEBOOK' },
      { name: 'Sample Sensor Dataset.csv', type: 'DATA' }
    ]
  }
];

export const INITIAL_EVENTS: CampusEvent[] = [
  {
    id: 'tech-fest-2026',
    title: 'Tech Fest 2026',
    date: '12 Oct 2026',
    time: '09:00 AM - 06:00 PM',
    location: 'Auditorium',
    category: 'technical',
    isHot: true,
    registered: false,
    description: 'The annual flagship technology extravaganza of KLE Society featuring 24-hr Hackathon, Robotics Arena, AI Showcase, and keynote talks from global tech innovators.',
    organizer: 'KLE Tech Council & GDG On Campus',
    seatsLeft: 42,
    bannerGradient: 'from-primary-container to-[#652cda]',
    icon: 'celebration'
  },
  {
    id: 'hack-kle-2026',
    title: 'HackKLE 36-Hour Hackathon',
    date: '16 Oct 2026',
    time: '08:00 AM Onwards',
    location: 'Innovation Lab, Block C',
    category: 'technical',
    registered: false,
    description: 'Build real-world solutions for Smart Agriculture, Healthcare AI, and Sustainable Mobility with ₹1,50,000 in prizes and direct mentorship from industry leaders.',
    organizer: 'Department of Computer Science',
    seatsLeft: 18,
    bannerGradient: 'from-[#00573a] to-[#40d399]',
    icon: 'code'
  },
  {
    id: 'ai-workshop',
    title: 'Google Cloud & Generative AI Workshop',
    date: '20 Oct 2026',
    time: '10:00 AM - 01:00 PM',
    location: 'Seminar Hall 2',
    category: 'workshop',
    registered: true,
    description: 'Hands-on training session on deploying multimodal AI agents and serverless backends with Cloud Run and Gemini API.',
    organizer: 'Google Developer Student Club',
    seatsLeft: 5,
    bannerGradient: 'from-[#3d00a1] to-[#7c3aed]',
    icon: 'psychology'
  },
  {
    id: 'cultural-night',
    title: 'Autumn Cultural Fiesta & Music Night',
    date: '24 Oct 2026',
    time: '05:30 PM - 10:00 PM',
    location: 'Open Air Amphitheatre',
    category: 'cultural',
    registered: false,
    description: 'An evening of classical and contemporary musical performances, dance drama, rock bands, and food stalls celebrating Karnataka culture.',
    organizer: 'Student Cultural Committee',
    seatsLeft: 120,
    bannerGradient: 'from-[#be185d] to-[#ec4899]',
    icon: 'theater_comedy'
  }
];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    title: 'Tech Fest 2026 Early Bird',
    message: 'Registrations are filling up fast for Tech Fest 2026 Auditorium sessions. Reserve your seat!',
    time: '10 mins ago',
    read: false,
    type: 'event'
  },
  {
    id: 'notif-2',
    title: 'Attendance Alert: 86% Met',
    message: 'Your overall attendance is currently 86%, comfortably above the 75% threshold.',
    time: '2 hours ago',
    read: false,
    type: 'academic'
  },
  {
    id: 'notif-3',
    title: 'Python Lab Assignment Uploaded',
    message: 'Prof. Sneha Patil posted Lab Session 6 exercise on the KLE Portal.',
    time: 'Yesterday',
    read: true,
    type: 'academic'
  }
];
