import React from 'react';
import { ASSETS } from '../data/mockData';
import { ScreenType } from '../types';

interface WelcomeScreenProps {
  onNavigate: (screen: ScreenType) => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onNavigate }) => {
  return (
    <div className="flex flex-col relative w-full min-h-screen bg-[#fcf8ff] text-[#1b192f] select-none">
      {/* Top Decorative Ambient Glow */}
      <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-80 h-80 bg-[#e8ddff]/60 rounded-full blur-3xl pointer-events-none -z-10" />

      {/* iOS Top Status Bar Emulation */}
      <header className="w-full pt-2 px-6 flex items-center justify-between z-20">
        <span className="text-[13px] font-semibold text-[#1b192f] tracking-tight">9:41</span>
        <div className="flex items-center space-x-1.5 text-[#1b192f]">
          <span className="material-symbols-outlined text-[15px] leading-none">signal_cellular_4_bar</span>
          <span className="material-symbols-outlined text-[15px] leading-none">wifi</span>
          <span className="material-symbols-outlined text-[17px] leading-none">battery_full</span>
        </div>
      </header>

      {/* Content Container */}
      <div className="flex flex-col items-center w-full px-6 pt-5 pb-6 flex-1 justify-between max-w-md mx-auto">
        <div className="w-full flex flex-col items-center">
          {/* Crest Badge Container with subtle tactile float */}
          <div
            onClick={() => onNavigate('dashboard')}
            className="relative group cursor-pointer transition-transform duration-300 active:scale-95"
          >
            <div className="w-20 h-20 rounded-full bg-white shadow-md shadow-[#5521c7]/10 flex items-center justify-center p-1.5 transition-all duration-300">
              <img
                src={ASSETS.logo}
                alt="KLE Society Crest"
                className="w-full h-full object-contain rounded-full"
              />
            </div>
            {/* Micro-accent badge */}
            <div className="absolute -bottom-1 -right-1 bg-[#3d00a1] text-white rounded-full p-1 shadow-sm flex items-center justify-center">
              <span
                className="material-symbols-outlined text-[12px] leading-none"
                style={{ fontVariationSettings: "'FILL' 1" }}
              >
                verified
              </span>
            </div>
          </div>

          {/* Typography Hierarchy */}
          <div className="text-center mt-5 space-y-1">
            <h1 className="text-[30px] font-bold text-[#1b192f] tracking-tight leading-[36px]">
              Campus Connect
            </h1>
            <p className="text-[17px] text-[#5521c7] font-semibold tracking-tight">
              Your Campus, Your Community
            </p>
            <p className="text-[13px] text-[#635b71] max-w-xs mx-auto pt-1 leading-relaxed">
              Classes, events and progress in one beautiful place
            </p>
          </div>

          {/* Campus Visual Card with Smooth Gradient Transition */}
          <div className="w-full mt-6 relative rounded-3xl overflow-hidden shadow-xl shadow-[#3d00a1]/5 aspect-[4/3] max-h-72">
            <img
              src={ASSETS.campusView}
              alt="KLE Society Campus Grounds"
              className="w-full h-full object-cover object-center transform scale-100 hover:scale-105 transition-transform duration-700 ease-out"
            />
            {/* Natural smooth purple-tinted soft scrim gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-transparent via-[#fcf8ff]/40 to-[#fcf8ff] pointer-events-none" />

            {/* Interactive Campus Micro-Pill Floating in Scenery */}
            <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between bg-white/85 backdrop-blur-md rounded-2xl px-4 py-2.5 shadow-sm border border-white/60">
              <div className="flex items-center space-x-2.5">
                <div className="w-2.5 h-2.5 rounded-full bg-[#4edea3] animate-pulse" />
                <span className="text-[13px] text-[#1b192f] font-medium">Autumn Term • KLE Hub</span>
              </div>
              <div className="flex items-center text-[#5521c7] space-x-0.5">
                <span className="material-symbols-outlined text-[16px]">location_on</span>
                <span className="text-[11px] font-semibold">Belagavi</span>
              </div>
            </div>
          </div>
        </div>

        {/* Floating Action Panel */}
        <div className="w-full mt-7 flex flex-col items-center space-y-4">
          {/* Primary Action CTA Button */}
          <button
            type="button"
            id="btnGetStarted"
            onClick={() => onNavigate('login')}
            className="w-full h-14 bg-[#5521c7] active:scale-[0.98] transition-all duration-200 text-white rounded-full px-6 flex items-center justify-between shadow-lg shadow-[#5521c7]/25 focus:outline-none cursor-pointer hover:bg-[#3d00a1]"
          >
            <span className="text-[17px] font-semibold tracking-tight pl-2">
              Get Started
            </span>
            <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center transition-transform group-hover:translate-x-0.5">
              <span className="material-symbols-outlined text-white text-[20px]">arrow_forward</span>
            </div>
          </button>

          {/* Secondary Sign-In Link */}
          <div className="pt-1 flex items-center justify-center space-x-1.5 text-center">
            <span className="text-[13px] text-[#635b71]">
              Already have an account?
            </span>
            <button
              type="button"
              id="btnSignIn"
              onClick={() => onNavigate('login')}
              className="text-[13px] font-bold text-[#5521c7] active:opacity-70 transition-opacity hover:underline cursor-pointer"
            >
              Sign In
            </button>
          </div>

          {/* iOS Home Indicator */}
          <div className="mt-8 flex justify-center w-full pb-safe">
            <div className="w-32 h-1 bg-[#cbc3d7]/60 rounded-full" />
          </div>
        </div>
      </div>
    </div>
  );
};
