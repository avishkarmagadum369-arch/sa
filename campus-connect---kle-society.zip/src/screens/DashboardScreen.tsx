import React, { useState } from 'react';
import { ASSETS } from '../data/mockData';
import { ClassSession, CampusEvent, StudentProfile } from '../types';

interface DashboardScreenProps {
  student: StudentProfile;
  classes: ClassSession[];
  events: CampusEvent[];
  onOpenNotifications: () => void;
  onOpenProfile: () => void;
  onSelectClass: (session: ClassSession) => void;
  onOpenAttendance: () => void;
  onViewAllClasses: () => void;
  onToggleEventRegister: (eventId: string) => void;
  onViewEventPass: (event: CampusEvent) => void;
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({
  student,
  classes,
  events,
  onOpenNotifications,
  onOpenProfile,
  onSelectClass,
  onOpenAttendance,
  onViewAllClasses,
  onToggleEventRegister,
  onViewEventPass,
}) => {
  const [hasUnreadAlert, setHasUnreadAlert] = useState(true);

  // Get Tech Fest 2026 (or first featured event)
  const featuredEvent = events.find((e) => e.id === 'tech-fest-2026') || events[0];

  const handleNotificationClick = () => {
    setHasUnreadAlert(false);
    onOpenNotifications();
  };

  return (
    <div className="flex flex-col w-full px-4 pb-6 space-y-5 max-w-md mx-auto">
      {/* Greeting Header */}
      <div className="flex items-center justify-between pt-2">
        <div className="flex items-center gap-3">
          <div
            onClick={onOpenProfile}
            className="relative cursor-pointer transition-transform active:scale-95"
          >
            <img
              alt="Sudarshan profile photo"
              className="w-12 h-12 rounded-full object-cover shadow-xs ring-2 ring-[#5521c7]/20"
              src={ASSETS.avatar}
            />
            <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-[#4edea3] ring-2 ring-[#fcf8ff]" />
          </div>
          <div className="flex flex-col min-w-0">
            <h1 className="text-[20px] text-[#1b192f] font-semibold tracking-tight truncate">
              Hello, {student.name}
            </h1>
            <p className="text-[13px] text-[#494454] font-medium">
              Thursday, 8 October
            </p>
          </div>
        </div>

        {/* Notification Button with tactile feedback */}
        <button
          aria-label="View notifications"
          id="notification-btn"
          type="button"
          onClick={handleNotificationClick}
          className="relative w-11 h-11 rounded-full bg-[#eae5ff] flex items-center justify-center text-[#1b192f] hover:bg-[#e4dffe] active:scale-90 transition-all duration-200 cursor-pointer"
        >
          <span className="material-symbols-outlined text-[22px]">notifications</span>
          {hasUnreadAlert && (
            <span className="absolute top-2.5 right-2.5 w-2 h-2 rounded-full bg-[#ba1a1a] ring-2 ring-[#fcf8ff] animate-pulse" />
          )}
        </button>
      </div>

      {/* Attendance Overview Card */}
      <div
        onClick={onOpenAttendance}
        role="button"
        tabIndex={0}
        aria-label="View Attendance Details"
        className="relative w-full rounded-3xl p-5 bg-gradient-to-br from-[#5521c7] via-[#652cda] to-[#3d00a1] text-white shadow-xl shadow-[#5521c7]/25 overflow-hidden cursor-pointer hover:shadow-2xl transition-all active:scale-[0.99] select-none group"
      >
        {/* Ambient organic backdrop aura */}
        <div className="absolute -right-12 -top-12 w-48 h-48 rounded-full bg-white/10 blur-2xl pointer-events-none" />
        <div className="absolute -left-10 -bottom-10 w-36 h-36 rounded-full bg-[#4edea3]/20 blur-xl pointer-events-none" />

        <div className="relative z-10 flex flex-col space-y-4">
          {/* Card Top Pill & Label */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/15 backdrop-blur-md">
              <span className="material-symbols-outlined text-[16px] text-[#6ffbbe]">event_available</span>
              <span className="text-[11px] text-white font-medium">Attendance Overview</span>
            </div>
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#00573a]/60 text-[#6ffbbe] text-[11px] font-semibold">
              <span className="material-symbols-outlined text-[14px]">check_circle</span>
              <span>On Track</span>
            </div>
          </div>

          {/* Main Dial + Percent Row */}
          <div className="flex items-center justify-between gap-3">
            <div className="flex flex-col">
              <div className="flex items-baseline gap-1">
                <span className="text-[34px] font-bold tracking-tight text-white leading-none">
                  {student.attendancePercent}%
                </span>
                <span className="text-[13px] text-[#c4b1ff] font-medium">total</span>
              </div>
              <div className="flex items-center gap-1.5 mt-1.5">
                <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-[#4edea3]/20 text-[#6ffbbe] text-[11px] font-semibold">
                  <span className="material-symbols-outlined text-[12px] mr-0.5">trending_up</span>
                  Great progress!
                </span>
              </div>
            </div>

            {/* Attendance SVG Circular Dial */}
            <div className="relative w-20 h-20 flex-shrink-0 flex items-center justify-center">
              <svg className="w-20 h-20 transform -rotate-90" viewBox="0 0 72 72">
                {/* Track circle */}
                <circle
                  className="stroke-white/20"
                  cx="36"
                  cy="36"
                  fill="transparent"
                  r="28"
                  strokeWidth="6.5"
                />
                {/* Progress Arc (86% of 175.92 ~ 151.29) -> offset 24.63 */}
                <circle
                  className="stroke-[#4edea3] transition-all duration-1000 ease-out"
                  cx="36"
                  cy="36"
                  fill="transparent"
                  r="28"
                  strokeDasharray="175.92"
                  strokeDashoffset="24.63"
                  strokeLinecap="round"
                  strokeWidth="6.5"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                <span className="material-symbols-outlined text-[20px] text-white">school</span>
              </div>
            </div>
          </div>

          {/* Footnote requirement bar */}
          <div className="pt-2 flex items-center justify-between text-[#c4b1ff] border-t border-white/10">
            <div className="flex items-center gap-1.5 text-[11px]">
              <span className="material-symbols-outlined text-[15px] text-[#6ffbbe]">verified</span>
              <span>Minimum requirement: 75% met</span>
            </div>
            <span className="text-[11px] font-semibold text-white/90">
              {student.attendedClasses}/{student.totalClasses} Attended
            </span>
          </div>
        </div>
      </div>

      {/* Today's Classes Section */}
      <div className="flex flex-col space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-[17px] text-[#1b192f] font-semibold tracking-tight">
              Today's Classes
            </h2>
            <span className="px-2 py-0.5 rounded-full bg-[#e7dbf6] text-[#675f75] text-[11px] font-semibold">
              {classes.length} Sessions
            </span>
          </div>
          <button
            onClick={onViewAllClasses}
            className="text-[13px] text-[#5521c7] font-semibold active:opacity-70 transition-opacity hover:underline cursor-pointer"
            type="button"
          >
            View all
          </button>
        </div>

        {/* Class Cards Stack */}
        <div className="flex flex-col space-y-3">
          {classes.map((cls) => (
            <div
              key={cls.id}
              role="button"
              tabIndex={0}
              onClick={() => onSelectClass(cls)}
              className="group w-full rounded-2xl bg-white p-4 shadow-xs hover:shadow-md transition-all duration-200 active:scale-[0.99] flex items-center justify-between cursor-pointer border border-[#e4dffe]/50"
            >
              <div className="flex items-center gap-3.5 min-w-0">
                <div
                  className={`w-12 h-12 rounded-xl ${cls.colorBg} flex items-center justify-center ${cls.colorText} flex-shrink-0 group-hover:scale-105 transition-transform`}
                >
                  <span className="material-symbols-outlined text-[24px]">{cls.icon}</span>
                </div>
                <div className="flex flex-col min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-[16px] text-[#1b192f] font-semibold truncate">
                      {cls.title}
                    </h3>
                    {cls.id === 'class-ds' && (
                      <span className="w-1.5 h-1.5 rounded-full bg-[#4edea3]" />
                    )}
                  </div>
                  <div className="flex items-center gap-2.5 mt-1 text-[#494454] text-[13px]">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#f0ebff] text-[#5521c7] text-[11px] font-medium">
                      <span className="material-symbols-outlined text-[13px]">schedule</span>
                      {cls.time}
                    </span>
                    <span className="inline-flex items-center gap-1 text-[11px] truncate text-[#494454]">
                      <span className="material-symbols-outlined text-[14px] text-[#635b71]">location_on</span>
                      {cls.room}
                    </span>
                  </div>
                </div>
              </div>
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-[#494454] group-hover:text-[#5521c7] group-hover:translate-x-0.5 transition-all flex-shrink-0">
                <span className="material-symbols-outlined text-[20px]">chevron_right</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Upcoming Event Section */}
      {featuredEvent && (
        <div className="flex flex-col space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-[17px] text-[#1b192f] font-semibold tracking-tight">
              Upcoming Event
            </h2>
            <span className="text-[11px] text-[#494454] font-medium">
              Campus Highlight
            </span>
          </div>

          {/* Lavender Tinted Event Card */}
          <div className="w-full rounded-2xl bg-[#f0ebff] p-4 shadow-xs flex items-center justify-between gap-3 hover:shadow-md transition-all duration-200 border border-[#e4dffe]">
            <div
              className="flex items-center gap-3.5 min-w-0 cursor-pointer flex-1"
              onClick={() => {
                if (featuredEvent.registered) {
                  onViewEventPass(featuredEvent);
                }
              }}
            >
              <div className="w-12 h-12 rounded-xl bg-[#5521c7] text-white flex items-center justify-center shadow-md shadow-[#5521c7]/20 flex-shrink-0">
                <span className="material-symbols-outlined text-[24px]">celebration</span>
              </div>
              <div className="flex flex-col min-w-0">
                <div className="flex items-center gap-1.5">
                  <h3 className="text-[16px] text-[#1b192f] font-bold truncate">
                    {featuredEvent.title}
                  </h3>
                  {featuredEvent.isHot && (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-[#6ffbbe] text-[#002113] leading-none">
                      HOT
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 mt-1 text-[#494454] text-[11px] truncate">
                  <span className="inline-flex items-center gap-1">
                    <span className="material-symbols-outlined text-[13px] text-[#5521c7]">calendar_month</span>
                    {featuredEvent.date}
                  </span>
                  <span>•</span>
                  <span className="inline-flex items-center gap-1 truncate">
                    <span className="material-symbols-outlined text-[13px] text-[#5521c7]">theater_comedy</span>
                    {featuredEvent.location}
                  </span>
                </div>
              </div>
            </div>

            <button
              id="register-fest-btn"
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleEventRegister(featuredEvent.id);
              }}
              className={`h-9 px-3.5 rounded-full font-semibold text-[13px] flex items-center justify-center flex-shrink-0 shadow-sm transition-all cursor-pointer ${
                featuredEvent.registered
                  ? 'bg-[#6ffbbe] text-[#002113] hover:bg-[#4edea3]'
                  : 'bg-[#5521c7] text-white hover:bg-[#3d00a1] active:scale-95 shadow-[#5521c7]/25'
              }`}
            >
              {featuredEvent.registered ? 'Registered ✓' : 'Register'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
