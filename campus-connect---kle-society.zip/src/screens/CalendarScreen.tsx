import React, { useState } from 'react';
import { ClassSession, CampusEvent } from '../types';

interface CalendarScreenProps {
  classes: ClassSession[];
  events: CampusEvent[];
  onSelectClass: (cls: ClassSession) => void;
}

export const CalendarScreen: React.FC<CalendarScreenProps> = ({
  classes,
  events,
  onSelectClass,
}) => {
  const [selectedDay, setSelectedDay] = useState<number>(8); // Thursday Oct 8
  const [activeFilter, setActiveFilter] = useState<'all' | 'classes' | 'events'>('all');

  const daysOfWeek = [
    { day: 'Mon', date: 5 },
    { day: 'Tue', date: 6 },
    { day: 'Wed', date: 7 },
    { day: 'Thu', date: 8, isToday: true },
    { day: 'Fri', date: 9 },
    { day: 'Sat', date: 10 },
    { day: 'Sun', date: 11 },
  ];

  return (
    <div className="flex flex-col w-full px-4 pb-6 space-y-4 max-w-md mx-auto">
      {/* Month & Year header */}
      <div className="flex items-center justify-between pt-2">
        <div>
          <h2 className="text-[20px] font-bold text-[#1b192f] tracking-tight">
            Academic Timetable
          </h2>
          <p className="text-[13px] text-[#635b71] font-medium">October 2026 • Autumn Term</p>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#e8ddff] text-[#5521c7] text-xs font-semibold">
          <span className="material-symbols-outlined text-[16px]">calendar_today</span>
          <span>Week 7</span>
        </div>
      </div>

      {/* Week Strip Picker */}
      <div className="grid grid-cols-7 gap-1.5 bg-white p-2.5 rounded-2xl border border-[#e4dffe] shadow-xs">
        {daysOfWeek.map((d) => {
          const isSelected = selectedDay === d.date;
          return (
            <button
              key={d.date}
              type="button"
              onClick={() => setSelectedDay(d.date)}
              className={`flex flex-col items-center py-2.5 rounded-xl transition-all cursor-pointer ${
                isSelected
                  ? 'bg-[#5521c7] text-white shadow-md shadow-[#5521c7]/25 font-bold scale-105'
                  : 'text-[#494454] hover:bg-[#f6f1ff]'
              }`}
            >
              <span className="text-[11px] font-medium opacity-80">{d.day}</span>
              <span className="text-[16px] font-bold mt-1">{d.date}</span>
              {d.isToday && !isSelected && (
                <span className="w-1.5 h-1.5 rounded-full bg-[#5521c7] mt-1" />
              )}
            </button>
          );
        })}
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2">
        {[
          { id: 'all', label: 'All Items' },
          { id: 'classes', label: 'Classes (3)' },
          { id: 'events', label: 'Events & Exams' },
        ].map((f) => (
          <button
            key={f.id}
            type="button"
            onClick={() => setActiveFilter(f.id as any)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
              activeFilter === f.id
                ? 'bg-[#5521c7] text-white'
                : 'bg-white border border-[#e4dffe] text-[#494454] hover:bg-[#f6f1ff]'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Day Schedule Timeline */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs font-bold text-[#635b71] uppercase tracking-wider px-1">
          <span>{selectedDay === 8 ? "Today's Schedule (Thu, 8 Oct)" : `Schedule for Oct ${selectedDay}`}</span>
          <span>KLE Hub • Block B</span>
        </div>

        {selectedDay === 8 ? (
          <div className="space-y-3">
            {classes.map((cls) => (
              <div
                key={cls.id}
                onClick={() => onSelectClass(cls)}
                className="p-4 bg-white rounded-2xl border border-[#e4dffe] shadow-xs flex items-center justify-between hover:border-[#5521c7]/40 cursor-pointer transition-all"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-11 h-11 rounded-xl ${cls.colorBg} ${cls.colorText} flex items-center justify-center font-bold`}
                  >
                    <span className="material-symbols-outlined text-[22px]">{cls.icon}</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm text-[#1b192f]">{cls.title}</h4>
                    <p className="text-xs text-[#635b71]">{cls.instructor} • {cls.room}</p>
                    <span className="inline-block mt-1 text-[11px] font-medium text-[#5521c7] bg-[#f0ebff] px-2 py-0.5 rounded-md">
                      {cls.time} ({cls.duration})
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="material-symbols-outlined text-[#635b71] text-[20px]">
                    chevron_right
                  </span>
                </div>
              </div>
            ))}

            {/* Extra schedule block */}
            <div className="p-3.5 bg-[#f6f1ff] rounded-2xl border border-dashed border-[#cbc3d7] flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white text-[#635b71] flex items-center justify-center">
                <span className="material-symbols-outlined text-[20px]">local_library</span>
              </div>
              <div>
                <h4 className="text-xs font-semibold text-[#1b192f]">Library & Study Hour</h4>
                <p className="text-[11px] text-[#635b71]">03:45 PM - 05:00 PM • Central Library 3rd Floor</p>
              </div>
            </div>
          </div>
        ) : (
          <div className="p-8 bg-white rounded-2xl border border-[#e4dffe] text-center space-y-2">
            <span className="material-symbols-outlined text-4xl text-[#cdc2dc]">event_busy</span>
            <p className="text-sm font-semibold text-[#1b192f]">No scheduled lectures on this date</p>
            <p className="text-xs text-[#635b71]">Check the academic notice board for revision batches</p>
          </div>
        )}
      </div>

      {/* Upcoming Academic Milestones */}
      <div className="p-4 bg-gradient-to-r from-[#f0ebff] to-[#e8ddff] rounded-2xl border border-[#cebdff]">
        <div className="flex items-center gap-2 mb-2">
          <span className="material-symbols-outlined text-[#5521c7] text-[20px]">flag</span>
          <h4 className="text-xs font-bold text-[#1b192f] uppercase tracking-wide">Key Milestone</h4>
        </div>
        <p className="text-xs text-[#1b192f] font-semibold">
          Mid-Term Practical Evaluations begin on 18 October 2026
        </p>
        <p className="text-[11px] text-[#635b71] mt-0.5">
          Ensure lab records and internal assessments are submitted by 15 October.
        </p>
      </div>
    </div>
  );
};
