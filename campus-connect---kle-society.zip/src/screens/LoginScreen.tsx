import React, { useState } from 'react';
import { ASSETS } from '../data/mockData';
import { ScreenType } from '../types';

interface LoginScreenProps {
  onNavigate: (screen: ScreenType) => void;
  onLoginSuccess: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  onNavigate,
  onLoginSuccess,
}) => {
  const [email, setEmail] = useState('student@klesociety.edu.in');
  const [password, setPassword] = useState('password123');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastIcon, setToastIcon] = useState('info');

  const showToast = (msg: string, icon = 'info') => {
    setToastMessage(msg);
    setToastIcon(icon);
    setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      showToast('Welcome back, Sudarshan!', 'check_circle');
      setTimeout(() => {
        onLoginSuccess();
      }, 700);
    }, 1000);
  };

  const handleGoogleAuth = () => {
    setLoading(true);
    showToast('Authenticating with KLE Google Workspace...', 'lock');
    setTimeout(() => {
      setLoading(false);
      onLoginSuccess();
    }, 900);
  };

  const triggerBiometric = () => {
    showToast('Biometric sensor ready. FaceID / Fingerprint recognized!', 'fingerprint');
    setTimeout(() => {
      onLoginSuccess();
    }, 1000);
  };

  return (
    <div className="flex flex-col relative w-full min-h-screen bg-[#fcf8ff] text-[#1b192f] antialiased">
      {/* Fixed Header */}
      <header className="fixed top-0 left-0 right-0 z-40 bg-[#fcf8ff]/85 backdrop-blur-xl pt-safe shadow-[0_1px_8px_rgba(0,0,0,0.04)] border-b border-[#e4dffe]/50">
        <div className="max-w-md mx-auto h-16 px-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              aria-label="Go Back"
              onClick={() => onNavigate('welcome')}
              className="w-10 h-10 flex items-center justify-center rounded-full text-[#1b192f] hover:bg-[#f0ebff] active:scale-95 transition-transform cursor-pointer"
            >
              <span className="material-symbols-outlined text-[24px]">arrow_back_ios_new</span>
            </button>
            <img
              alt="KLE Society College Logo"
              className="h-8 w-auto object-contain"
              src={ASSETS.logo}
            />
            <span className="text-[17px] font-semibold text-[#1b192f]">
              Login Authentication
            </span>
          </div>
          <div className="flex items-center">
            <img
              alt="Profile"
              className="w-8 h-8 rounded-full object-cover ring-2 ring-[#5521c7]/20"
              src={ASSETS.avatar}
            />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex flex-col relative w-full pt-16 flex-1 max-w-md mx-auto">
        <div className="flex flex-col w-full px-4 pb-safe flex-1 justify-between">
          {/* Top Subtle Ambient Glow */}
          <div className="relative w-full overflow-hidden flex flex-col items-center">
            <div className="absolute -top-16 left-1/2 -translate-x-1/2 w-64 h-64 bg-[#e8ddff] rounded-full blur-3xl opacity-40 pointer-events-none" />

            {/* Campus Emblem Badge & Welcome Text */}
            <div className="mt-4 mb-5 flex flex-col items-center text-center relative z-10">
              <div className="w-16 h-16 rounded-2xl bg-white shadow-md flex items-center justify-center p-2 mb-3 transition-transform active:scale-95 duration-200">
                <img
                  alt="KLE Society Emblem"
                  className="w-12 h-12 object-contain"
                  src={ASSETS.logo}
                />
              </div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#e7dbf6]/60 mb-2">
                <span className="w-2 h-2 rounded-full bg-[#4edea3] animate-pulse" />
                <span className="text-[11px] text-[#675f75] font-semibold tracking-wide uppercase">
                  Student Portal
                </span>
              </div>
              <h1 className="text-[24px] font-bold text-[#1b192f] tracking-tight mb-1">
                Welcome back!
              </h1>
              <p className="text-[15px] text-[#635b71]">
                Sign in to your campus account
              </p>
            </div>

            {/* Interactive Auth Form Card */}
            <div className="w-full bg-white rounded-3xl p-5 shadow-sm space-y-4 relative z-10 border border-[#e4dffe]/60">
              <form className="space-y-4" onSubmit={handleLoginSubmit}>
                {/* Email Input Group */}
                <div className="flex flex-col gap-1.5 text-left">
                  <label className="text-[13px] text-[#1b192f] font-semibold pl-1" htmlFor="emailInput">
                    Email Address
                  </label>
                  <div className="relative flex items-center bg-[#f6f1ff] rounded-2xl transition-all focus-within:bg-white focus-within:shadow-[0_0_0_2px_rgba(85,33,199,0.35)]">
                    <span className="material-symbols-outlined text-[#635b71] ml-4 text-[20px] select-none pointer-events-none">
                      mail
                    </span>
                    <input
                      className="w-full bg-transparent py-3.5 pl-3 pr-4 text-[15px] text-[#1b192f] placeholder:text-[#7a7486] focus:outline-none"
                      id="emailInput"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="student@klesociety.edu.in"
                      required
                    />
                  </div>
                </div>

                {/* Password Input Group */}
                <div className="flex flex-col gap-1.5 text-left">
                  <div className="flex items-center justify-between px-1">
                    <label className="text-[13px] text-[#1b192f] font-semibold" htmlFor="passwordInput">
                      Password
                    </label>
                    <button
                      type="button"
                      onClick={() => showToast('Password reset link sent to your registered college email.', 'mark_email_read')}
                      className="text-[13px] text-[#5521c7] font-semibold hover:opacity-80 active:opacity-60 transition-opacity cursor-pointer"
                    >
                      Forgot password?
                    </button>
                  </div>
                  <div className="relative flex items-center bg-[#f6f1ff] rounded-2xl transition-all focus-within:bg-white focus-within:shadow-[0_0_0_2px_rgba(85,33,199,0.35)]">
                    <span className="material-symbols-outlined text-[#635b71] ml-4 text-[20px] select-none pointer-events-none">
                      lock
                    </span>
                    <input
                      className="w-full bg-transparent py-3.5 pl-3 pr-11 text-[15px] text-[#1b192f] placeholder:text-[#7a7486] tracking-wider focus:outline-none"
                      id="passwordInput"
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••••••"
                      required
                    />
                    <button
                      aria-label="Toggle password visibility"
                      className="absolute right-2 w-10 h-10 flex items-center justify-center rounded-xl text-[#635b71] hover:text-[#1b192f] active:scale-95 transition-all cursor-pointer"
                      onClick={() => setShowPassword(!showPassword)}
                      type="button"
                    >
                      <span className="material-symbols-outlined text-[20px]">
                        {showPassword ? 'visibility_off' : 'visibility'}
                      </span>
                    </button>
                  </div>
                </div>

                {/* Quick Remember & Bio Check */}
                <div className="flex items-center justify-between pt-1">
                  <label className="flex items-center gap-2.5 cursor-pointer select-none">
                    <input
                      className="sr-only"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      type="checkbox"
                    />
                    <div
                      className={`w-5 h-5 rounded-md flex items-center justify-center transition-colors shadow-inner ${
                        rememberMe ? 'bg-[#5521c7]' : 'bg-[#e4dffe]'
                      }`}
                    >
                      {rememberMe && (
                        <span className="material-symbols-outlined text-white text-[15px]">
                          check
                        </span>
                      )}
                    </div>
                    <span className="text-[13px] text-[#635b71]">Keep me signed in</span>
                  </label>

                  <button
                    aria-label="Use FaceID/TouchID"
                    className="p-2 -mr-1 rounded-xl text-[#5521c7] active:scale-90 transition-transform cursor-pointer hover:bg-[#f0ebff]"
                    onClick={triggerBiometric}
                    type="button"
                  >
                    <span className="material-symbols-outlined text-[24px]">fingerprint</span>
                  </button>
                </div>

                {/* Primary Action Button */}
                <button
                  className="w-full min-h-[52px] mt-2 bg-[#5521c7] text-white text-[17px] font-semibold rounded-full shadow-[0_10px_25px_-5px_rgba(85,33,199,0.4)] flex items-center justify-center gap-2 hover:bg-[#3d00a1] active:scale-[0.98] transition-all cursor-pointer disabled:opacity-70"
                  type="submit"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <span className="material-symbols-outlined animate-spin text-[20px]">
                        progress_activity
                      </span>
                      <span>Verifying...</span>
                    </>
                  ) : (
                    <>
                      <span>Sign In</span>
                      <span className="material-symbols-outlined text-[20px]">arrow_forward</span>
                    </>
                  )}
                </button>
              </form>

              {/* Minimal Soft Divider */}
              <div className="relative py-2 flex items-center justify-center">
                <div className="w-full h-[1px] bg-[#e4dffe]" />
                <span className="absolute bg-white px-3 text-[11px] uppercase tracking-wider text-[#635b71] font-medium">
                  or continue with
                </span>
              </div>

              {/* Alternative SSO Auth Button */}
              <button
                className="w-full min-h-[52px] bg-white hover:bg-[#f6f1ff] border border-[#e4dffe] text-[#1b192f] text-[15px] font-semibold rounded-full shadow-xs flex items-center justify-center gap-3 active:scale-[0.98] transition-all cursor-pointer"
                onClick={handleGoogleAuth}
                type="button"
              >
                {/* Crisp Google SVG Icon */}
                <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24">
                  <path
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                    fill="#4285F4"
                  />
                  <path
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                    fill="#34A853"
                  />
                  <path
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.97 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                    fill="#FBBC05"
                  />
                  <path
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                    fill="#EA4335"
                  />
                </svg>
                <span>Campus Google Account</span>
              </button>
            </div>

            {/* Security Micro-Callout */}
            <div className="mt-4 flex items-center justify-center gap-1.5 text-[#635b71] text-[12px]">
              <span className="material-symbols-outlined text-[16px] text-[#00573a]">
                verified_user
              </span>
              <span>Protected by KLE Multi-Factor Authentication</span>
            </div>

            {/* Footer Switcher */}
            <div className="mt-4 mb-4 text-center">
              <p className="text-[14px] text-[#635b71]">
                Don’t have an account?{' '}
                <button
                  className="text-[14px] text-[#5521c7] font-semibold hover:underline ml-1 cursor-pointer"
                  onClick={() => showToast('Contact Student Affairs at Belagavi campus to activate student ID.', 'badge')}
                  type="button"
                >
                  Sign up
                </button>
              </p>
            </div>
          </div>

          {/* iOS Home Bar Spacer */}
          <div className="w-full flex justify-center pb-2 pt-2">
            <div className="w-32 h-1 bg-[#cbc3d7]/60 rounded-full" />
          </div>
        </div>
      </main>

      {/* Micro Toast Notification Element */}
      {toastMessage && (
        <div className="fixed bottom-8 left-1/2 -translate-x-1/2 max-w-[90%] bg-[#302e45] text-[#f3eeff] px-4 py-3 rounded-2xl shadow-xl flex items-center gap-3 transition-all duration-300 z-50 animate-in fade-in slide-in-from-bottom-2">
          <span className="material-symbols-outlined text-[20px] text-[#4edea3]">
            {toastIcon}
          </span>
          <span className="text-[13px] font-medium">{toastMessage}</span>
        </div>
      )}
    </div>
  );
};
