import React, { useState } from 'react';
import { CampusEvent } from '../types';

interface EventsScreenProps {
  events: CampusEvent[];
  onToggleEventRegister: (id: string) => void;
  onViewEventPass: (event: CampusEvent) => void;
}

export const EventsScreen: React.FC<EventsScreenProps> = ({
  events,
  onToggleEventRegister,
  onViewEventPass,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredEvents = events.filter((e) => {
    const matchesCat = selectedCategory === 'all' || e.category === selectedCategory;
    const matchesQuery =
      e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.location.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesQuery;
  });

  return (
    <div className="flex flex-col w-full px-4 pb-6 space-y-4 max-w-md mx-auto">
      {/* Title Header */}
      <div className="flex items-center justify-between pt-2">
        <div>
          <h2 className="text-[20px] font-bold text-[#1b192f] tracking-tight">
            Campus Events & Highlights
          </h2>
          <p className="text-[13px] text-[#635b71] font-medium">
            KLE Society Belagavi Campus
          </p>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#6ffbbe]/30 text-[#003d28] text-xs font-bold">
          <span className="material-symbols-outlined text-[16px]">celebration</span>
          <span>4 Active</span>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative flex items-center bg-white rounded-2xl border border-[#e4dffe] px-3.5 py-2.5 shadow-xs focus-within:border-[#5521c7]">
        <span className="material-symbols-outlined text-[#635b71] text-[20px] mr-2">search</span>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search fest, hackathon, workshop..."
          className="w-full text-xs text-[#1b192f] placeholder:text-[#7a7486] bg-transparent focus:outline-none"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="text-[#635b71] hover:text-[#1b192f] cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        )}
      </div>

      {/* Category Pills */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
        {[
          { id: 'all', label: 'All Highlights' },
          { id: 'technical', label: 'Technical' },
          { id: 'workshop', label: 'Workshops' },
          { id: 'cultural', label: 'Cultural' },
        ].map((cat) => (
          <button
            key={cat.id}
            type="button"
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              selectedCategory === cat.id
                ? 'bg-[#5521c7] text-white shadow-xs'
                : 'bg-white border border-[#e4dffe] text-[#494454] hover:bg-[#f6f1ff]'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Event Cards */}
      <div className="space-y-3.5">
        {filteredEvents.map((ev) => (
          <div
            key={ev.id}
            className="bg-white rounded-3xl border border-[#e4dffe] overflow-hidden shadow-xs hover:shadow-md transition-all duration-200"
          >
            {/* Top gradient strip */}
            <div className={`p-4 bg-gradient-to-r ${ev.bannerGradient} text-white flex items-center justify-between`}>
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                  <span className="material-symbols-outlined text-[20px]">{ev.icon}</span>
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-full">
                    {ev.category}
                  </span>
                </div>
              </div>
              {ev.isHot && (
                <span className="px-2 py-0.5 rounded text-[11px] font-extrabold bg-[#6ffbbe] text-[#002113]">
                  HOT
                </span>
              )}
            </div>

            {/* Event Body */}
            <div className="p-4 space-y-3">
              <div>
                <h3 className="text-[16px] font-bold text-[#1b192f] leading-snug">
                  {ev.title}
                </h3>
                <p className="text-xs text-[#494454] mt-1 line-clamp-2 leading-relaxed">
                  {ev.description}
                </p>
              </div>

              {/* Meta information */}
              <div className="grid grid-cols-2 gap-2 text-xs text-[#635b71] bg-[#fcf8ff] p-2.5 rounded-xl border border-[#e4dffe]/60">
                <div className="flex items-center gap-1.5 truncate">
                  <span className="material-symbols-outlined text-[#5521c7] text-[16px]">calendar_month</span>
                  <span className="truncate">{ev.date}</span>
                </div>
                <div className="flex items-center gap-1.5 truncate">
                  <span className="material-symbols-outlined text-[#5521c7] text-[16px]">location_on</span>
                  <span className="truncate">{ev.location}</span>
                </div>
                <div className="flex items-center gap-1.5 truncate">
                  <span className="material-symbols-outlined text-[#5521c7] text-[16px]">schedule</span>
                  <span className="truncate">{ev.time}</span>
                </div>
                <div className="flex items-center gap-1.5 truncate">
                  <span className="material-symbols-outlined text-[#5521c7] text-[16px]">groups</span>
                  <span className="truncate">{ev.seatsLeft} spots left</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-1 gap-2">
                {ev.registered ? (
                  <>
                    <button
                      type="button"
                      onClick={() => onViewEventPass(ev)}
                      className="flex-1 py-2 px-3 bg-[#f0ebff] hover:bg-[#e4dffe] text-[#5521c7] rounded-full text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <span className="material-symbols-outlined text-[16px]">qr_code</span>
                      View Digital Pass
                    </button>
                    <button
                      type="button"
                      onClick={() => onToggleEventRegister(ev.id)}
                      className="py-2 px-3 bg-[#6ffbbe] text-[#002113] rounded-full text-xs font-bold transition-all cursor-pointer hover:bg-[#4edea3]"
                    >
                      Registered ✓
                    </button>
                  </>
                ) : (
                  <button
                    type="button"
                    onClick={() => onToggleEventRegister(ev.id)}
                    className="w-full py-2.5 bg-[#5521c7] hover:bg-[#3d00a1] text-white rounded-full text-xs font-bold transition-all shadow-md shadow-[#5521c7]/20 flex items-center justify-center gap-1.5 cursor-pointer active:scale-[0.98]"
                  >
                    <span>Register Now</span>
                    <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
