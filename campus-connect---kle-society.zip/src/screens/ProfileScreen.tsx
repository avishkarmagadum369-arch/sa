import React, { useState } from 'react';
import { StudentProfile, ScreenType } from '../types';
import { ASSETS } from '../data/mockData';

interface ProfileScreenProps {
  student: StudentProfile;
  onLogout: () => void;
  onNavigate: (screen: ScreenType) => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  student,
  onLogout,
  onNavigate,
}) => {
  const [showIdCard, setShowIdCard] = useState(false);
  const [mfaStatus, setMfaStatus] = useState(student.mfaEnabled);

  return (
    <div className="flex flex-col w-full px-4 pb-6 space-y-4 max-w-md mx-auto">
      {/* Profile Header */}
      <div className="flex items-center justify-between pt-2">
        <h2 className="text-[20px] font-bold text-[#1b192f] tracking-tight">
          Student Profile
        </h2>
        <span className="px-2.5 py-1 rounded-full bg-[#00573a]/10 text-[#00573a] text-xs font-bold flex items-center gap-1">
          <span className="material-symbols-outlined text-[14px]">verified</span>
          Verified Student
        </span>
      </div>

      {/* Student ID Virtual Badge Card */}
      <div className="relative rounded-3xl p-5 bg-gradient-to-br from-[#3d00a1] via-[#5521c7] to-[#652cda] text-white shadow-xl shadow-[#5521c7]/25 overflow-hidden">
        {/* Glow & Holographic Effect */}
        <div className="absolute -right-8 -top-8 w-40 h-40 rounded-full bg-white/10 blur-xl pointer-events-none" />
        <div className="absolute -left-10 -bottom-10 w-32 h-32 rounded-full bg-[#4edea3]/20 blur-lg pointer-events-none" />

        <div className="relative z-10 flex flex-col space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <img src={ASSETS.logo} alt="KLE Logo" className="h-7 w-auto brightness-0 invert" />
              <div>
                <p className="text-[11px] font-bold tracking-wider uppercase text-[#cebdff]">
                  KLE Society
                </p>
                <p className="text-[10px] text-white/80">Institute of Technology</p>
              </div>
            </div>
            <button
              onClick={() => setShowIdCard(!showIdCard)}
              className="text-[11px] font-semibold bg-white/20 hover:bg-white/30 px-2.5 py-1 rounded-full transition-colors cursor-pointer"
            >
              {showIdCard ? 'Hide Card' : 'Flip ID'}
            </button>
          </div>

          <div className="flex items-center gap-4 pt-1">
            <div className="relative flex-shrink-0">
              <img
                src={ASSETS.avatar}
                alt="Sudarshan Patil"
                className="w-16 h-16 rounded-2xl object-cover ring-2 ring-white/40 shadow-md"
              />
              <span className="absolute -bottom-1 -right-1 bg-[#4edea3] text-[#002113] rounded-full p-0.5">
                <span className="material-symbols-outlined text-[12px] block">verified</span>
              </span>
            </div>

            <div className="min-w-0">
              <h3 className="text-[18px] font-bold text-white tracking-tight leading-tight">
                {student.name} Patil
              </h3>
              <p className="text-xs text-[#cebdff] mt-0.5 font-medium">{student.branch}</p>
              <div className="flex items-center gap-2 mt-1.5 text-[11px] text-white/90">
                <span className="bg-white/15 px-2 py-0.5 rounded font-mono font-semibold">
                  USN: {student.usn}
                </span>
                <span>{student.semester.split(' ')[0]}</span>
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-white/15 flex items-center justify-between text-xs text-[#c4b1ff]">
            <span>Campus: {student.campus}</span>
            <span className="font-mono text-white/90 font-semibold">{student.studentId}</span>
          </div>
        </div>
      </div>

      {/* Academic Metrics Grid */}
      <div className="grid grid-cols-3 gap-2.5">
        <div className="bg-white p-3.5 rounded-2xl border border-[#e4dffe] text-center shadow-xs">
          <p className="text-[10px] font-bold text-[#635b71] uppercase tracking-wider">CGPA</p>
          <p className="text-[20px] font-extrabold text-[#5521c7] mt-0.5">{student.cgpa}</p>
          <span className="text-[10px] text-[#00573a] font-semibold">Top 5%</span>
        </div>
        <div className="bg-white p-3.5 rounded-2xl border border-[#e4dffe] text-center shadow-xs">
          <p className="text-[10px] font-bold text-[#635b71] uppercase tracking-wider">Attendance</p>
          <p className="text-[20px] font-extrabold text-[#00573a] mt-0.5">{student.attendancePercent}%</p>
          <span className="text-[10px] text-[#00573a] font-semibold">Eligible</span>
        </div>
        <div className="bg-white p-3.5 rounded-2xl border border-[#e4dffe] text-center shadow-xs">
          <p className="text-[10px] font-bold text-[#635b71] uppercase tracking-wider">Credits</p>
          <p className="text-[20px] font-extrabold text-[#1b192f] mt-0.5">{student.completedCredits}</p>
          <span className="text-[10px] text-[#635b71] font-semibold">of {student.totalCredits}</span>
        </div>
      </div>

      {/* Security & Settings Card */}
      <div className="bg-white rounded-3xl border border-[#e4dffe] p-4 shadow-xs space-y-3">
        <h4 className="text-xs font-bold text-[#635b71] uppercase tracking-wider">
          Security & Identity
        </h4>

        {/* MFA row */}
        <div className="flex items-center justify-between py-1">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#e8ddff] text-[#5521c7] flex items-center justify-center">
              <span className="material-symbols-outlined text-[20px]">shield</span>
            </div>
            <div>
              <p className="text-sm font-semibold text-[#1b192f]">KLE Multi-Factor Auth</p>
              <p className="text-[11px] text-[#635b71]">Hardware token & Biometrics active</p>
            </div>
          </div>
          <button
            onClick={() => setMfaStatus(!mfaStatus)}
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
              mfaStatus ? 'bg-[#5521c7]' : 'bg-[#cbc3d7]'
            }`}
          >
            <span
              className={`absolute top-1 left-1 w-4 h-4 rounded-full bg-white transition-transform ${
                mfaStatus ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Registered Email */}
        <div className="flex items-center justify-between py-1 border-t border-[#f0ebff]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#f0ebff] text-[#635b71] flex items-center justify-center">
              <span className="material-symbols-outlined text-[20px]">email</span>
            </div>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-[#1b192f]">Campus Email</p>
              <p className="text-[11px] text-[#635b71] truncate">{student.email}</p>
            </div>
          </div>
          <span className="text-[11px] font-bold text-[#00573a] bg-[#00573a]/10 px-2 py-0.5 rounded-full">
            Linked
          </span>
        </div>
      </div>

      {/* Navigation Quick Switch */}
      <div className="bg-white rounded-3xl border border-[#e4dffe] p-4 shadow-xs space-y-2">
        <h4 className="text-xs font-bold text-[#635b71] uppercase tracking-wider mb-2">
          Switch Prototype Screens
        </h4>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => onNavigate('welcome')}
            className="p-2.5 rounded-xl bg-[#f6f1ff] text-[#5521c7] text-xs font-semibold hover:bg-[#e8ddff] transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">touch_app</span>
            Welcome Screen
          </button>
          <button
            onClick={() => onNavigate('login')}
            className="p-2.5 rounded-xl bg-[#f6f1ff] text-[#5521c7] text-xs font-semibold hover:bg-[#e8ddff] transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">lock</span>
            Login Screen
          </button>
        </div>
      </div>

      {/* Sign Out CTA */}
      <button
        onClick={onLogout}
        className="w-full py-3 bg-[#ffdad6] hover:bg-[#ffb4ab] text-[#ba1a1a] rounded-full font-bold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
      >
        <span className="material-symbols-outlined text-[18px]">logout</span>
        Sign Out from Student Portal
      </button>
    </div>
  );
};
