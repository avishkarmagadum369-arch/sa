import React from 'react';
import { ScreenType } from '../types';

interface BottomNavProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentScreen, onNavigate }) => {
  const tabs: { key: ScreenType; label: string; icon: string }[] = [
    { key: 'dashboard', label: 'Home', icon: 'grid_view' },
    { key: 'calendar', label: 'Calendar', icon: 'calendar_today' },
    { key: 'events', label: 'Events', icon: 'celebration' },
    { key: 'profile', label: 'Profile', icon: 'account_circle' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 pb-safe bg-[#fcf8ff]/90 backdrop-blur-xl shadow-[0_-4px_20px_rgba(23,21,43,0.06)] border-t border-[#e4dffe]/60">
      <div className="max-w-md mx-auto flex justify-around items-center h-16 px-2">
        {tabs.map((tab) => {
          const isActive = currentScreen === tab.key;
          return (
            <button
              key={tab.key}
              type="button"
              onClick={() => onNavigate(tab.key)}
              aria-current={isActive ? 'page' : undefined}
              className={`flex flex-col items-center justify-center min-w-[56px] min-h-[48px] px-2 rounded-xl transition-all duration-200 cursor-pointer ${
                isActive
                  ? 'text-[#5521c7] font-semibold scale-105'
                  : 'text-[#494454] hover:text-[#1b192f] active:scale-95'
              }`}
            >
              <span
                className="material-symbols-outlined text-[24px]"
                style={isActive ? { fontVariationSettings: "'FILL' 1" } : undefined}
              >
                {tab.icon}
              </span>
              <span className="text-[11px] font-medium mt-0.5 tracking-tight">
                {tab.label}
              </span>
              {isActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-[#5521c7] mt-0.5 animate-pulse" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
