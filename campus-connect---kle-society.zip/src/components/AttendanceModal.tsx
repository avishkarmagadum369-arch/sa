import React, { useState } from 'react';
import { StudentProfile } from '../types';

interface AttendanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: StudentProfile;
}

export const AttendanceModal: React.FC<AttendanceModalProps> = ({
  isOpen,
  onClose,
  student,
}) => {
  const [targetGoal, setTargetGoal] = useState<number>(85);

  if (!isOpen) return null;

  const subjects = [
    { name: 'Data Structure', code: 'CS501', attended: 10, total: 11, faculty: 'Dr. Radhika Desai' },
    { name: 'Cloud Computing', code: 'CS502', attended: 8, total: 9, faculty: 'Prof. Amit Kulkarni' },
    { name: 'Python Lab', code: 'CS503L', attended: 6, total: 8, faculty: 'Prof. Sneha Patil' },
    { name: 'Database Management Systems', code: 'CS504', attended: 9, total: 10, faculty: 'Prof. Rajesh K' },
  ];

  // Calculate overall
  const totalAttended = student.attendedClasses;
  const totalConducted = student.totalClasses;
  const currentPct = Math.round((totalAttended / totalConducted) * 100);

  // Calculate classes that can be missed while staying >= 75%
  // (attended) / (conducted + x) >= 0.75 => attended >= 0.75 * conducted + 0.75 * x
  // 0.75 * x <= attended - 0.75 * conducted => x <= (attended - 0.75 * conducted) / 0.75
  const canMiss = Math.max(0, Math.floor((totalAttended - 0.75 * totalConducted) / 0.75));

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-[#1b192f]/50 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-[#fcf8ff] rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col border border-[#e4dffe]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-[#e4dffe] flex items-center justify-between bg-gradient-to-r from-[#5521c7] to-[#3d00a1] text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/15 backdrop-blur-md flex items-center justify-center">
              <span className="material-symbols-outlined text-[22px] text-[#6ffbbe]">event_available</span>
            </div>
            <div>
              <h3 className="font-bold text-[18px]">Attendance Details</h3>
              <p className="text-[12px] text-[#cebdff]">KLE Society VTU Academic Regulation</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 text-white flex items-center justify-center hover:bg-white/30 transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto p-4 sm:p-5 space-y-4 flex-1">
          {/* Main Stat Banner */}
          <div className="bg-white rounded-2xl p-4 border border-[#e4dffe] shadow-sm flex items-center justify-between">
            <div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-3xl font-extrabold text-[#3d00a1] tracking-tight">
                  {currentPct}%
                </span>
                <span className="text-xs font-semibold text-[#635b71] uppercase tracking-wider">
                  Overall
                </span>
              </div>
              <p className="text-xs text-[#494454] mt-0.5">
                {totalAttended} attended out of {totalConducted} classes conducted
              </p>
            </div>
            <div className="text-right">
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#00573a]/10 text-[#00573a] text-xs font-semibold">
                <span className="material-symbols-outlined text-[14px]">check_circle</span>
                Eligible for Exams
              </span>
              <p className="text-[11px] text-[#635b71] mt-1">Min. Required: 75%</p>
            </div>
          </div>

          {/* Buffer Calculator */}
          <div className="bg-[#f0ebff] rounded-2xl p-4 border border-[#cebdff]/60">
            <div className="flex items-center gap-2 mb-1.5">
              <span className="material-symbols-outlined text-[#5521c7] text-[20px]">calculate</span>
              <h4 className="text-sm font-bold text-[#1b192f]">Safe Margin Calculator</h4>
            </div>
            <p className="text-xs text-[#494454] leading-relaxed">
              You can miss up to <span className="font-bold text-[#5521c7]">{canMiss} more classes</span> without dropping below the university 75% requirement.
            </p>
            <div className="mt-3 flex items-center justify-between bg-white rounded-xl p-2.5 border border-[#e4dffe]">
              <span className="text-xs font-medium text-[#494454]">Target Goal:</span>
              <div className="flex gap-1.5">
                {[80, 85, 90].map((goal) => (
                  <button
                    key={goal}
                    type="button"
                    onClick={() => setTargetGoal(goal)}
                    className={`px-2.5 py-1 text-xs rounded-lg font-semibold transition-all cursor-pointer ${
                      targetGoal === goal
                        ? 'bg-[#5521c7] text-white shadow-sm'
                        : 'bg-[#f6f1ff] text-[#494454] hover:bg-[#e4dffe]'
                    }`}
                  >
                    {goal}%
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Subject Breakdown */}
          <div>
            <h4 className="text-xs font-bold text-[#635b71] uppercase tracking-wider mb-2.5">
              Course-wise Attendance
            </h4>
            <div className="space-y-2.5">
              {subjects.map((sub) => {
                const pct = Math.round((sub.attended / sub.total) * 100);
                const isSafe = pct >= 75;
                return (
                  <div
                    key={sub.code}
                    className="p-3.5 bg-white rounded-2xl border border-[#e4dffe] shadow-xs hover:border-[#cebdff] transition-all"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div>
                        <div className="flex items-center gap-2">
                          <h5 className="font-semibold text-[14px] text-[#1b192f]">{sub.name}</h5>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#f0ebff] text-[#5521c7] font-semibold">
                            {sub.code}
                          </span>
                        </div>
                        <p className="text-[11px] text-[#635b71]">{sub.faculty}</p>
                      </div>
                      <div className="text-right">
                        <span className={`text-[15px] font-bold ${isSafe ? 'text-[#00573a]' : 'text-[#ba1a1a]'}`}>
                          {pct}%
                        </span>
                        <p className="text-[10px] text-[#635b71]">
                          {sub.attended}/{sub.total} sessions
                        </p>
                      </div>
                    </div>
                    {/* Progress Bar */}
                    <div className="w-full bg-[#f0ebff] h-2 rounded-full overflow-hidden mt-2">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          pct >= 85 ? 'bg-[#40d399]' : pct >= 75 ? 'bg-[#5521c7]' : 'bg-[#ba1a1a]'
                        }`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#f6f1ff] border-t border-[#e4dffe] flex justify-end">
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-[#5521c7] text-white rounded-full font-semibold text-sm hover:bg-[#3d00a1] active:scale-[0.98] transition-all cursor-pointer shadow-md shadow-[#5521c7]/20"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};
