import React from 'react';
import { CampusEvent, StudentProfile } from '../types';
import { ASSETS } from '../data/mockData';

interface EventPassModalProps {
  event: CampusEvent | null;
  student: StudentProfile;
  onClose: () => void;
}

export const EventPassModal: React.FC<EventPassModalProps> = ({
  event,
  student,
  onClose,
}) => {
  if (!event) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1b192f]/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-sm bg-white rounded-3xl shadow-2xl overflow-hidden border border-[#e4dffe] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Pass Top Banner */}
        <div className="p-5 bg-gradient-to-r from-[#5521c7] via-[#652cda] to-[#3d00a1] text-white text-center relative overflow-hidden">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <img src={ASSETS.logo} alt="KLE Logo" className="h-6 w-auto brightness-0 invert" />
              <span className="text-xs font-bold tracking-wide uppercase">KLE Society Pass</span>
            </div>
            <button
              onClick={onClose}
              className="w-7 h-7 rounded-full bg-white/20 text-white flex items-center justify-center hover:bg-white/30 transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">close</span>
            </button>
          </div>
          <span className="inline-block px-2.5 py-0.5 rounded-full bg-[#6ffbbe] text-[#002113] text-[11px] font-bold uppercase tracking-wider mb-2">
            Verified Student Pass
          </span>
          <h3 className="text-xl font-bold tracking-tight">{event.title}</h3>
          <p className="text-xs text-[#c4b1ff] mt-0.5">{event.date} • {event.location}</p>
        </div>

        {/* Perforated divider look */}
        <div className="relative flex items-center justify-between px-3 py-2 bg-white">
          <div className="w-5 h-5 rounded-full bg-[#1b192f]/60 -ml-5.5" />
          <div className="flex-1 border-b-2 border-dashed border-[#cbc3d7] mx-2" />
          <div className="w-5 h-5 rounded-full bg-[#1b192f]/60 -mr-5.5" />
        </div>

        {/* Ticket Details Body */}
        <div className="p-5 bg-white space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[10px] text-[#635b71] uppercase font-bold tracking-wider">Attendee</p>
              <p className="text-sm font-bold text-[#1b192f]">{student.name} Patil</p>
              <p className="text-xs text-[#494454]">{student.usn}</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] text-[#635b71] uppercase font-bold tracking-wider">Seat / Gate</p>
              <p className="text-sm font-bold text-[#5521c7]">Zone A • Seat 42</p>
              <p className="text-xs text-[#494454]">Main Auditorium</p>
            </div>
          </div>

          {/* QR Code Graphic Emulation */}
          <div className="p-4 bg-[#f6f1ff] rounded-2xl border border-[#e4dffe] flex flex-col items-center justify-center">
            <div className="w-36 h-36 bg-white p-2 rounded-xl shadow-inner border border-[#cbc3d7]/50 flex items-center justify-center">
              {/* Clean SVG Mock QR */}
              <svg className="w-full h-full text-[#1b192f]" viewBox="0 0 100 100" fill="currentColor">
                <rect x="10" y="10" width="25" height="25" />
                <rect x="15" y="15" width="15" height="15" fill="white" />
                <rect x="18" y="18" width="9" height="9" />
                <rect x="65" y="10" width="25" height="25" />
                <rect x="70" y="15" width="15" height="15" fill="white" />
                <rect x="73" y="18" width="9" height="9" />
                <rect x="10" y="65" width="25" height="25" />
                <rect x="15" y="70" width="15" height="15" fill="white" />
                <rect x="18" y="73" width="9" height="9" />
                {/* Random QR clusters */}
                <rect x="42" y="12" width="6" height="6" />
                <rect x="52" y="12" width="6" height="6" />
                <rect x="42" y="24" width="6" height="6" />
                <rect x="48" y="32" width="6" height="6" />
                <rect x="12" y="45" width="6" height="6" />
                <rect x="24" y="45" width="6" height="6" />
                <rect x="36" y="45" width="6" height="6" />
                <rect x="48" y="45" width="6" height="6" />
                <rect x="60" y="45" width="6" height="6" />
                <rect x="72" y="45" width="6" height="6" />
                <rect x="84" y="45" width="6" height="6" />
                <rect x="42" y="60" width="6" height="6" />
                <rect x="54" y="60" width="6" height="6" />
                <rect x="66" y="60" width="6" height="6" />
                <rect x="42" y="72" width="6" height="6" />
                <rect x="60" y="72" width="6" height="6" />
                <rect x="78" y="72" width="6" height="6" />
                <rect x="48" y="84" width="6" height="6" />
                <rect x="66" y="84" width="6" height="6" />
                <rect x="84" y="84" width="6" height="6" />
              </svg>
            </div>
            <p className="text-[11px] font-mono text-[#635b71] mt-2 font-semibold tracking-wider">
              PASS #KLE-TF26-98124
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#f6f1ff] border-t border-[#e4dffe] flex items-center justify-between">
          <span className="text-[11px] text-[#635b71] font-medium">Show at security gate</span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#5521c7] text-white rounded-full font-semibold text-xs hover:bg-[#3d00a1] transition-all cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
