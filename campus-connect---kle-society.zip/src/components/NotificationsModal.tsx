import React from 'react';
import { NotificationItem } from '../types';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: NotificationItem[];
  onMarkAllAsRead: () => void;
  onClear: () => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkAllAsRead,
  onClear,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-[#1b192f]/50 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-[#fcf8ff] rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden max-h-[85vh] flex flex-col border border-[#e4dffe]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#e4dffe] flex items-center justify-between bg-[#f0ebff]/60">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-[#5521c7] text-white flex items-center justify-center">
              <span className="material-symbols-outlined text-[20px]">notifications</span>
            </div>
            <div>
              <h3 className="font-semibold text-[17px] text-[#1b192f]">Campus Notifications</h3>
              <p className="text-[12px] text-[#494454]">Alerts, classes & campus updates</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#e4dffe] text-[#494454] flex items-center justify-center hover:bg-[#d0c6fa] transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {/* Action Bar */}
        <div className="px-4 py-2 bg-[#f6f1ff] flex items-center justify-between border-b border-[#e4dffe]/60 text-xs">
          <span className="font-medium text-[#494454]">
            {notifications.filter((n) => !n.read).length} unread updates
          </span>
          <div className="flex items-center gap-3">
            <button
              onClick={onMarkAllAsRead}
              className="text-[#5521c7] hover:underline font-semibold cursor-pointer"
            >
              Mark all read
            </button>
            <button
              onClick={onClear}
              className="text-[#635b71] hover:text-[#ba1a1a] transition-colors cursor-pointer"
            >
              Clear
            </button>
          </div>
        </div>

        {/* Notification List */}
        <div className="overflow-y-auto p-4 space-y-3 flex-1">
          {notifications.length === 0 ? (
            <div className="text-center py-10 text-[#494454]">
              <span className="material-symbols-outlined text-4xl text-[#cdc2dc] mb-2">notifications_off</span>
              <p className="text-sm font-medium">No new notifications</p>
              <p className="text-xs text-[#635b71] mt-1">You are all caught up for today!</p>
            </div>
          ) : (
            notifications.map((item) => (
              <div
                key={item.id}
                className={`p-3.5 rounded-2xl border transition-all ${
                  item.read
                    ? 'bg-white border-[#e4dffe]/60'
                    : 'bg-[#f0ebff] border-[#5521c7]/30 shadow-sm ring-1 ring-[#5521c7]/15'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5 ${
                      item.type === 'academic'
                        ? 'bg-[#e8ddff] text-[#5521c7]'
                        : item.type === 'event'
                        ? 'bg-[#00573a] text-[#6ffbbe]'
                        : 'bg-[#ffdad6] text-[#ba1a1a]'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[18px]">
                      {item.type === 'academic' ? 'school' : item.type === 'event' ? 'celebration' : 'warning'}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1 mb-1">
                      <h4 className="text-[14px] font-semibold text-[#1b192f] truncate">
                        {item.title}
                      </h4>
                      <span className="text-[11px] text-[#494454] whitespace-nowrap">
                        {item.time}
                      </span>
                    </div>
                    <p className="text-[13px] text-[#494454] leading-relaxed">
                      {item.message}
                    </p>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#f6f1ff] border-t border-[#e4dffe] text-center">
          <p className="text-[11px] text-[#635b71]">
            Official notices synced from KLE Society Student Affairs
          </p>
        </div>
      </div>
    </div>
  );
};
