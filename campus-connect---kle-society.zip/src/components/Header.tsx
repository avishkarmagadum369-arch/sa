import React from 'react';
import { ASSETS } from '../data/mockData';
import { ScreenType } from '../types';

interface HeaderProps {
  title?: string;
  subtitle?: string;
  showBack?: boolean;
  onBack?: () => void;
  unreadCount?: number;
  onOpenNotifications?: () => void;
  onOpenProfile?: () => void;
  currentScreen?: ScreenType;
}

export const Header: React.FC<HeaderProps> = ({
  title = 'Campus Connect',
  subtitle = 'Student Dashboard',
  showBack = false,
  onBack,
  unreadCount = 2,
  onOpenNotifications,
  onOpenProfile,
}) => {
  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-[#fcf8ff]/85 backdrop-blur-xl pt-safe shadow-[0_1px_8px_rgba(0,0,0,0.04)] border-b border-[#e4dffe]/50">
      <div className="max-w-md mx-auto h-16 px-4 flex items-center justify-between">
        {/* Left Side: Back button or KLE Logo */}
        <div className="flex items-center gap-2 min-w-0">
          {showBack && (
            <button
              onClick={onBack}
              aria-label="Go Back"
              className="w-10 h-10 flex items-center justify-center rounded-full text-[#1b192f] hover:bg-[#f0ebff] active:scale-95 transition-transform mr-1 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[22px]">arrow_back_ios_new</span>
            </button>
          )}

          <div
            onClick={onBack && !showBack ? undefined : () => {}}
            className="flex items-center gap-2 cursor-pointer select-none"
          >
            <img
              src={ASSETS.logo}
              alt="KLE Society College Logo"
              className="h-8 w-auto object-contain flex-shrink-0"
            />
            <div className="flex flex-col min-w-0 leading-tight">
              <span className="text-[17px] font-semibold text-[#1b192f] tracking-tight truncate">
                {title}
              </span>
              {subtitle && (
                <span className="text-[11px] font-medium text-[#494454] tracking-wide truncate">
                  {subtitle}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Right Side: Notification Icon & Profile Avatar */}
        <div className="flex items-center gap-1.5 flex-shrink-0">
          {onOpenNotifications && (
            <button
              type="button"
              onClick={onOpenNotifications}
              aria-label="Notifications"
              className="relative w-11 h-11 flex items-center justify-center rounded-full text-[#1b192f] hover:bg-[#f0ebff] active:scale-95 transition-transform cursor-pointer"
            >
              <span className="material-symbols-outlined text-[24px]">notifications</span>
              {unreadCount > 0 && (
                <span className="absolute top-2.5 right-2.5 w-2.5 h-2.5 rounded-full bg-[#ba1a1a] ring-2 ring-[#fcf8ff] animate-pulse" />
              )}
            </button>
          )}

          <button
            type="button"
            onClick={onOpenProfile}
            aria-label="Profile"
            className="relative w-9 h-9 rounded-full ring-2 ring-[#5521c7]/20 hover:ring-[#5521c7] active:scale-95 transition-all overflow-hidden cursor-pointer"
          >
            <img
              src={ASSETS.avatar}
              alt="Sudarshan Patil"
              className="w-full h-full object-cover"
            />
          </button>
        </div>
      </div>
    </header>
  );
};
