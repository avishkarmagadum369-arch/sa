import React, { useState } from 'react';
import { ClassSession } from '../types';

interface ClassDetailsModalProps {
  classSession: ClassSession | null;
  onClose: () => void;
  onCheckIn?: (classId: string) => void;
}

export const ClassDetailsModal: React.FC<ClassDetailsModalProps> = ({
  classSession,
  onClose,
  onCheckIn,
}) => {
  const [checkedIn, setCheckedIn] = useState(false);
  const [downloading, setDownloading] = useState<string | null>(null);

  if (!classSession) return null;

  const handleCheckIn = () => {
    setCheckedIn(true);
    if (onCheckIn) {
      onCheckIn(classSession.id);
    }
  };

  const handleDownload = (name: string) => {
    setDownloading(name);
    setTimeout(() => {
      setDownloading(null);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-[#1b192f]/50 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-[#fcf8ff] rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col border border-[#e4dffe]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-[#e4dffe] flex items-center justify-between bg-[#f0ebff]">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-2xl ${classSession.colorBg} ${classSession.colorText} flex items-center justify-center shadow-xs`}>
              <span className="material-symbols-outlined text-[26px]">{classSession.icon}</span>
            </div>
            <div>
              <h3 className="font-bold text-[18px] text-[#1b192f]">{classSession.title}</h3>
              <p className="text-[12px] text-[#635b71] font-medium">{classSession.instructor}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#e4dffe] text-[#494454] flex items-center justify-center hover:bg-[#d0c6fa] transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto p-4 sm:p-5 space-y-4 flex-1">
          {/* Timing & Venue Banner */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-white rounded-2xl border border-[#e4dffe] flex items-center gap-2.5">
              <span className="material-symbols-outlined text-[#5521c7] text-[22px]">schedule</span>
              <div>
                <p className="text-[10px] text-[#635b71] uppercase font-bold tracking-wider">Time</p>
                <p className="text-[13px] font-semibold text-[#1b192f]">{classSession.time}</p>
              </div>
            </div>
            <div className="p-3 bg-white rounded-2xl border border-[#e4dffe] flex items-center gap-2.5">
              <span className="material-symbols-outlined text-[#5521c7] text-[22px]">location_on</span>
              <div>
                <p className="text-[10px] text-[#635b71] uppercase font-bold tracking-wider">Venue</p>
                <p className="text-[13px] font-semibold text-[#1b192f]">{classSession.room}</p>
              </div>
            </div>
          </div>

          {/* Today's Topic */}
          <div className="p-4 bg-white rounded-2xl border border-[#e4dffe] space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#5521c7] uppercase tracking-wider">
                Today's Lecture Agenda
              </span>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-[#f0ebff] text-[#5521c7] font-semibold">
                {classSession.duration}
              </span>
            </div>
            <h4 className="text-[15px] font-semibold text-[#1b192f] leading-snug">
              {classSession.topicToday}
            </h4>
            <p className="text-xs text-[#635b71]">
              Curriculum reference: {classSession.syllabusUnit}
            </p>
          </div>

          {/* Attendance Check-in Action */}
          <div className="p-4 bg-[#f0ebff] rounded-2xl border border-[#cebdff]/60 flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-[#1b192f]">Digital Attendance Check-In</p>
              <p className="text-[11px] text-[#635b71]">
                {checkedIn ? 'Marked present by beacon verification' : 'BLE Beacon active in Room B-204'}
              </p>
            </div>
            <button
              type="button"
              onClick={handleCheckIn}
              disabled={checkedIn}
              className={`px-4 py-2 rounded-full text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                checkedIn
                  ? 'bg-[#00573a] text-white'
                  : 'bg-[#5521c7] text-white hover:bg-[#3d00a1] active:scale-95 shadow-sm shadow-[#5521c7]/20'
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">
                {checkedIn ? 'check_circle' : 'fingerprint'}
              </span>
              {checkedIn ? 'Checked In' : 'Check In'}
            </button>
          </div>

          {/* Course Material Resources */}
          <div>
            <h4 className="text-xs font-bold text-[#635b71] uppercase tracking-wider mb-2">
              Courseware & Slides
            </h4>
            <div className="space-y-2">
              {classSession.resources.map((res, i) => (
                <div
                  key={i}
                  className="p-3 bg-white rounded-xl border border-[#e4dffe] flex items-center justify-between hover:border-[#cebdff] transition-colors"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="material-symbols-outlined text-[#5521c7] text-[20px]">
                      description
                    </span>
                    <span className="text-xs font-medium text-[#1b192f] truncate">
                      {res.name}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleDownload(res.name)}
                    className="text-xs text-[#5521c7] font-semibold hover:underline px-2 py-1 cursor-pointer flex-shrink-0"
                  >
                    {downloading === res.name ? 'Opening...' : 'View'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#f6f1ff] border-t border-[#e4dffe]">
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-white border border-[#cbc3d7] text-[#1b192f] rounded-full font-semibold text-sm hover:bg-[#f0ebff] active:scale-[0.98] transition-all cursor-pointer"
          >
            Close Details
          </button>
        </div>
      </div>
    </div>
  );
};
