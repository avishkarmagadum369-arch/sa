export type ScreenType = 'welcome' | 'login' | 'dashboard' | 'calendar' | 'events' | 'profile';

export interface StudentProfile {
  name: string;
  email: string;
  studentId: string;
  usn: string;
  branch: string;
  semester: string;
  college: string;
  campus: string;
  avatarUrl: string;
  cgpa: number;
  totalCredits: number;
  completedCredits: number;
  attendancePercent: number;
  attendedClasses: number;
  totalClasses: number;
  mfaEnabled: boolean;
}

export interface ClassSession {
  id: string;
  title: string;
  time: string;
  duration: string;
  room: string;
  instructor: string;
  colorBg: string;
  colorText: string;
  icon: string;
  attended: number;
  total: number;
  topicToday: string;
  syllabusUnit: string;
  resources: { name: string; type: string }[];
}

export interface CampusEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  category: 'technical' | 'cultural' | 'workshop' | 'sports';
  isHot?: boolean;
  registered: boolean;
  description: string;
  organizer: string;
  seatsLeft: number;
  bannerGradient: string;
  icon: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'academic' | 'event' | 'alert';
}
